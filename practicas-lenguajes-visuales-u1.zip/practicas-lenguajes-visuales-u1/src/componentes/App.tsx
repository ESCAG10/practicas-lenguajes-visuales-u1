import React from 'react';
import './Apps.css';

const App: React.FC = () => {
  const [count, setCount] = React.useState<number>(0);

  const incrementar = (): void => {
    setCount(count + 1);
  };

  const decrementar = (): void => {
    setCount(count - 1);
  };

  return (
    <div className="app-container">
      <h1>Aplicación en React + TypeScript</h1>
      
      <p>Contador: {count}</p>
      
      <div className="buttons">
        <button onClick={incrementar}>Incrementar</button>
        <button onClick={decrementar}>Decrementar</button>
      </div>
    </div>
  );
};

export default App;
